/*
============================================
; Title:  townsend-assignment-4.4
; Author: Ethan Townsend
; Date:   7/31/2019
; Description: web-425
;===========================================
*/

export class Fruit {
    id: number;
    name: string;
    pricePerPound: string;
    quantity: number;
}
